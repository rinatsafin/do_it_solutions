
export const GET_MOVIES = 'get_movies';
export const GET_GAMES = 'get_games';
export const GET_CELEBRITIES = 'get_celebrities'