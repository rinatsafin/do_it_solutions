import { combineReducers } from 'redux';
import data from './data_reducer'

const rootReducer = combineReducers({
    data
});

export default rootReducer;