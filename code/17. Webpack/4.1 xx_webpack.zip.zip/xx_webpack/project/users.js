const data = {
    age:25,
    name:"Francis"
}

export default data;