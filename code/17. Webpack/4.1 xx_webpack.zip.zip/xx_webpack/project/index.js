import data from './users';
import './css/style.css';
import './css/user.css';

console.log(`My name is ${data.name}, i am ${data.age} years old`);