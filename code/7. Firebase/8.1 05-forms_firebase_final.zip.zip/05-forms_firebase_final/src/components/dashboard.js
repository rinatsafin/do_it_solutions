import React from 'react';

const dashboard = (props) => {

    return(
        <div>
            The dashboard should be private
        </div>
    )
}

export default dashboard;