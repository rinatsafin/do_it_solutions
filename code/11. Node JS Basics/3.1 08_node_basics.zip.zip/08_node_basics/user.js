

module.exports.addLog = () => {
    return false
}